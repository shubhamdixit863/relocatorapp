<?php

//<!--Greeting : To |H۪۫۰۰۪۫O۪۫۰۰۪۫U۪۫۰۰۪۫S۪۫۰۰۪۫S۪۫۰۰۪۫E۪۫۰۰۪۫M۪۫۰ -->

include ('makelang.php');
header('Location: newdir.php');
?>